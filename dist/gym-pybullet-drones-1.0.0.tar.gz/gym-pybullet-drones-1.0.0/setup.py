# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gym_pybullet_drones',
 'gym_pybullet_drones.control',
 'gym_pybullet_drones.envs',
 'gym_pybullet_drones.envs.multi_agent_rl',
 'gym_pybullet_drones.envs.single_agent_rl',
 'gym_pybullet_drones.examples',
 'gym_pybullet_drones.utils']

package_data = \
{'': ['*'], 'gym_pybullet_drones': ['assets/*']}

install_requires = \
['Pillow>=9.0,<10.0',
 'cycler>=0.10,<0.11',
 'gym>=0.21,<0.22',
 'matplotlib>=3.5,<4.0',
 'numpy>=1.22,<2.0',
 'pybullet>=3.2,<4.0',
 'ray==1.9',
 'scipy>=1.8,<2.0',
 'stable-baselines3>=1.5,<2.0']

setup_kwargs = {
    'name': 'gym-pybullet-drones',
    'version': '1.0.0',
    'description': 'PyBullet Gym environments for single and multi-agent reinforcement learning of quadcopter control',
    'long_description': None,
    'author': 'Jacopo Panerati',
    'author_email': 'jacopo.panerati@utoronto.ca',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
